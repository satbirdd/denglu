var users = {
    9:
    {
        "name" : "wanliutest9test",
        "id" : "525661fc59c25dc5a5969868"
    },
    10:
    {
        "name" : "wanliutest10test",
        "id" : "525661fc59c25dc5a5969869"
    },
    12:
    {
        "name" : "wanliutest12test",
        "id" : "525661fc59c25dc5a596986b"
    },
    13:
    {
        "name" : "wanliutest13test",
        "id" : "525661fc59c25dc5a596986c"
    },
    14:
    {
        "name" : "wanliutest14test",
        "id" : "525661fc59c25dc5a596986d"
    },
    15:
    {
        "name" : "wanliutest15test",
        "id" : "525661fc59c25dc5a596986e"
    },
    16:
    {
        "name" : "wanliutest16test",
        "id" : "525661fc59c25dc5a596986f"
    },
    17:
    {
        "name" : "wanliutest17test",
        "id" : "525661fc59c25dc5a5969870"
    },
    18:
    {
        "name" : "wanliutest18test",
        "id" : "525661fc59c25dc5a5969871"
    },
    19:
    {
        "name" : "wanliutest19test",
        "id" : "525661fc59c25dc5a5969872"
    },
    21:
    {
        "name" : "wanliutest21test",
        "id" : "525661fc59c25dc5a5969874"
    },
    22:
    {
        "name" : "wanliutest22test",
        "id" : "525661fc59c25dc5a5969875"
    },
    23:
    {
        "name" : "wanliutest23test",
        "id" : "525661fc59c25dc5a5969876"
    },
    24:
    {
        "name" : "wanliutest24test",
        "id" : "525661fc59c25dc5a5969877"
    },
    25:
    {
        "name" : "wanliutest25test",
        "id" : "525661fc59c25dc5a5969878"
    },
    26:
    {
        "name" : "wanliutest26test",
        "id" : "525661fc59c25dc5a5969879"
    },
    27:
    {
        "name" : "wanliutest27test",
        "id" : "525661fc59c25dc5a596987a"
    },
    28:
    {
        "name" : "wanliutest28test",
        "id" : "525661fc59c25dc5a596987b"
    },
    29:
    {
        "name" : "wanliutest29test",
        "id" : "525661fc59c25dc5a596987c"
    },
    30:
    {
        "name" : "wanliutest30test",
        "id" : "525661fc59c25dc5a596987d"
    },
    31:
    {
        "name" : "wanliutest31test",
        "id" : "525661fc59c25dc5a596987e"
    },
    32:
    {
        "name" : "wanliutest32test",
        "id" : "525661fc59c25dc5a596987f"
    },
    33:
    {
        "name" : "wanliutest33test",
        "id" : "525661fc59c25dc5a5969880"
    },
    34:
    {
        "name" : "wanliutest34test",
        "id" : "525661fc59c25dc5a5969881"
    },
    35:
    {
        "name" : "wanliutest35test",
        "id" : "525661fc59c25dc5a5969882"
    },
    36:
    {
        "name" : "wanliutest36test",
        "id" : "525661fc59c25dc5a5969883"
    },
    37:
    {
        "name" : "wanliutest37test",
        "id" : "525661fc59c25dc5a5969884"
    },
    38:
    {
        "name" : "wanliutest38test",
        "id" : "525661fc59c25dc5a5969885"
    },
    39:
    {
        "name" : "wanliutest39test",
        "id" : "525661fc59c25dc5a5969886"
    },
    40:
    {
        "name" : "wanliutest40test",
        "id" : "525661fc59c25dc5a5969887"
    },
    41:
    {
        "name" : "wanliutest41test",
        "id" : "525661fc59c25dc5a5969888"
    },
    42:
    {
        "name" : "wanliutest42test",
        "id" : "525661fc59c25dc5a5969889"
    },
    43:
    {
        "name" : "wanliutest43test",
        "id" : "525661fc59c25dc5a596988a"
    },
    44:
    {
        "name" : "wanliutest44test",
        "id" : "525661fc59c25dc5a596988b"
    },
    45:
    {
        "name" : "wanliutest45test",
        "id" : "525661fc59c25dc5a596988c"
    },
    46:
    {
        "name" : "wanliutest46test",
        "id" : "525661fc59c25dc5a596988d"
    },
    47:
    {
        "name" : "wanliutest47test",
        "id" : "525661fc59c25dc5a596988e"
    },
    48:
    {
        "name" : "wanliutest48test",
        "id" : "525661fc59c25dc5a596988f"
    },
    49:
    {
        "name" : "wanliutest49test",
        "id" : "525661fc59c25dc5a5969890"
    },
    50:
    {
        "name" : "wanliutest50test",
        "id" : "525661fc59c25dc5a5969891"
    },
    51:
    {
        "name" : "wanliutest51test",
        "id" : "525661fc59c25dc5a5969892"
    },
    52:
    {
        "name" : "wanliutest52test",
        "id" : "525661fc59c25dc5a5969893"
    },
    53:
    {
        "name" : "wanliutest53test",
        "id" : "525661fc59c25dc5a5969894"
    },
    54:
    {
        "name" : "wanliutest54test",
        "id" : "525661fc59c25dc5a5969895"
    },
    55:
    {
        "name" : "wanliutest55test",
        "id" : "525661fc59c25dc5a5969896"
    },
    56:
    {
        "name" : "wanliutest56test",
        "id" : "525661fc59c25dc5a5969897"
    },
    57:
    {
        "name" : "wanliutest57test",
        "id" : "525661fc59c25dc5a5969898"
    },
    58:
    {
        "name" : "wanliutest58test",
        "id" : "525661fc59c25dc5a5969899"
    },
    59:
    {
        "name" : "wanliutest59test",
        "id" : "525661fc59c25dc5a596989a"
    },
    60:
    {
        "name" : "wanliutest60test",
        "id" : "525661fc59c25dc5a596989b"
    },
    61:
    {
        "name" : "wanliutest61test",
        "id" : "525661fc59c25dc5a596989c"
    },
    62:
    {
        "name" : "wanliutest62test",
        "id" : "525661fc59c25dc5a596989d"
    },
    63:
    {
        "name" : "wanliutest63test",
        "id" : "525661fc59c25dc5a596989e"
    },
    64:
    {
        "name" : "wanliutest64test",
        "id" : "525661fc59c25dc5a596989f"
    },
    65:
    {
        "name" : "wanliutest65test",
        "id" : "525661fc59c25dc5a59698a0"
    },
    66:
    {
        "name" : "wanliutest66test",
        "id" : "525661fc59c25dc5a59698a1"
    },
    67:
    {
        "name" : "wanliutest67test",
        "id" : "525661fc59c25dc5a59698a2"
    },
    68:
    {
        "name" : "wanliutest68test",
        "id" : "525661fc59c25dc5a59698a3"
    },
    69:
    {
        "name" : "wanliutest69test",
        "id" : "525661fc59c25dc5a59698a4"
    },
    70:
    {
        "name" : "wanliutest70test",
        "id" : "525661fc59c25dc5a59698a5"
    },
    71:
    {
        "name" : "wanliutest71test",
        "id" : "525661fc59c25dc5a59698a6"
    },
    72:
    {
        "name" : "wanliutest72test",
        "id" : "525661fc59c25dc5a59698a7"
    },
    73:
    {
        "name" : "wanliutest73test",
        "id" : "525661fc59c25dc5a59698a8"
    },
    74:
    {
        "name" : "wanliutest74test",
        "id" : "525661fc59c25dc5a59698a9"
    },
    75:
    {
        "name" : "wanliutest75test",
        "id" : "525661fc59c25dc5a59698aa"
    },
    76:
    {
        "name" : "wanliutest76test",
        "id" : "525661fc59c25dc5a59698ab"
    },
    77:
    {
        "name" : "wanliutest77test",
        "id" : "525661fc59c25dc5a59698ac"
    },
    78:
    {
        "name" : "wanliutest78test",
        "id" : "525661fc59c25dc5a59698ad"
    },
    79:
    {
        "name" : "wanliutest79test",
        "id" : "525661fc59c25dc5a59698ae"
    },
    80:
    {
        "name" : "wanliutest80test",
        "id" : "525661fc59c25dc5a59698af"
    },
    81:
    {
        "name" : "wanliutest81test",
        "id" : "525661fc59c25dc5a59698b0"
    },
    82:
    {
        "name" : "wanliutest82test",
        "id" : "525661fc59c25dc5a59698b1"
    },
    83:
    {
        "name" : "wanliutest83test",
        "id" : "525661fc59c25dc5a59698b2"
    },
    84:
    {
        "name" : "wanliutest84test",
        "id" : "525661fc59c25dc5a59698b3"
    },
    85:
    {
        "name" : "wanliutest85test",
        "id" : "525661fc59c25dc5a59698b4"
    },
    86:
    {
        "name" : "wanliutest86test",
        "id" : "525661fc59c25dc5a59698b5"
    },
    87:
    {
        "name" : "wanliutest87test",
        "id" : "525661fc59c25dc5a59698b6"
    },
    88:
    {
        "name" : "wanliutest88test",
        "id" : "525661fc59c25dc5a59698b7"
    },
    89:
    {
        "name" : "wanliutest89test",
        "id" : "525661fc59c25dc5a59698b8"
    },
    90:
    {
        "name" : "wanliutest90test",
        "id" : "525661fc59c25dc5a59698b9"
    },
    91:
    {
        "name" : "wanliutest91test",
        "id" : "525661fc59c25dc5a59698ba"
    },
    92:
    {
        "name" : "wanliutest92test",
        "id" : "525661fc59c25dc5a59698bb"
    },
    93:
    {
        "name" : "wanliutest93test",
        "id" : "525661fc59c25dc5a59698bc"
    },
    94:
    {
        "name" : "wanliutest94test",
        "id" : "525661fc59c25dc5a59698bd"
    },
    95:
    {
        "name" : "wanliutest95test",
        "id" : "525661fc59c25dc5a59698be"
    },
    96:
    {
        "name" : "wanliutest96test",
        "id" : "525661fc59c25dc5a59698bf"
    },
    97:
    {
        "name" : "wanliutest97test",
        "id" : "525661fc59c25dc5a59698c0"
    },
    98:
    {
        "name" : "wanliutest98test",
        "id" : "525661fc59c25dc5a59698c1"
    },
    99:
    {
        "name" : "wanliutest99test",
        "id" : "525661fc59c25dc5a59698c2"
    },
    1:
    {
        "name" : "wanliutest1test",
        "id" : "525661fc59c25dc5a5969860"
    },
    3:
    {
        "name" : "wanliutest3test",
        "id" : "525661fc59c25dc5a5969862"
    },
    2:
    {
        "name" : "wanliutest2test",
        "id" : "525661fc59c25dc5a5969861"
    },
    4:
    {
        "name" : "wanliutest4test",
        "id" : "525661fc59c25dc5a5969863"
    },
    5:
    {
        "name" : "wanliutest5test",
        "id" : "525661fc59c25dc5a5969864"
    },
    6:
    {
        "name" : "wanliutest6test",
        "id" : "525661fc59c25dc5a5969865"
    },
    7:
    {
        "name" : "wanliutest7test",
        "id" : "525661fc59c25dc5a5969866"
    },
    8:
    {
        "name" : "wanliutest8test",
        "id" : "525661fc59c25dc5a5969867"
    },
    11:
    {
        "name" : "wanliutest11test",
        "id" : "525661fc59c25dc5a596986a"
    },
    20:
    {
        "name" : "wanliutest20test",
        "id" : "525661fc59c25dc5a5969873"
    }
}

chrome.runtime.onMessage.addListener(function(quest, sender, sendResponse) {
    console.log(quest.open_tab)
    if (quest.open_tab) {
        var begin = quest.begin;
        var end = quest.end;
        for (var index = begin; index <= end; index ++) {
            var user = users[index];
            var url = "http://caramal-example.wanliu.biz/id=" + user.id;
            chrome.tabs.create({
                url: url,
                active: false
            })
        }
    }
})